# Proot face files (as running on the visor, 2026-11-10)

Everything you need to edit and design the visor's faces. The visor has TWO 64x32 LED panels. Each face is ONE 64x32 image for one side; the firmware draws it on
panel 1 and the same image mirrored left-right on panel 2, so you draw only half of the face (the nose/centre line is the RIGHT edge of your 64x32 image).
Exception: bsod.png is 128x32 and is NOT mirrored.

## Folders
- `faces_current/`      the 21 sprites exactly as they are on the visor now (decoded from the live firmware, includes smug2 which the upstream folder lacks). Edit these.
- `faces_current_4x/`   the same images enlarged 4x (view only, handy for checking). `contact-sheet.png` shows all of them mirrored the way the visor shows them.
- `animations_current/` the 3 boop animations the visor plays, rebuilt from the firmware: `bk.gif` (13 frames, 100 ms), `bk1_.gif` (52 frames, 20 ms, a fast one), `bk2_.gif`
  (6 frames, 100-160 ms), plus every frame as a PNG in `frames/` (edit frames, then re-assemble to a GIF with the same timing).
- `upstream_originals/` the original ProotOS sprites, GIFs and GIMP files (`face.xcf`, `animation.xcf`, `bsod.xcf`) plus the converters `convimg.py` and `convgif.py` and the MIT licence.
- `firmware_definitions/` `faces.h`, `boops.h`, `facemodifiers.h`: how sprites are wired into faces, thresholds, and the visual effects (for reference).

## Which sprite does what
| Face (selector number) | Idle sprite | Blink | Talking mouth sprites | Talks? |
|---|---|---|---|---|
| 1 normal | normal | blink | talk1-5 (quiet), loud1-5 (louder), yell1-5 (loudest) | yes, driven by mic level |
| 2 smug | smug | blink | none | no |
| 3 smug 2 | smug2 | blink | none | no |
| 4 normal (silent) | normal | blink | none | no |
Boop animations (random pick, played when the boop sensor triggers or a command asks): bk (gif), bk1_ (gif), bk2_ (gif), amogus (still, 2.5 s), bsod (still 128x32, 2.5 s).

## Rules for the images (so they survive onto the LEDs)
- Exactly 64x32 pixels (bsod.png is 128x32). No transparency, no anti-aliasing / soft edges, no scaling: nearest-neighbour only.
- Pure black = LED off. Black background is the norm. Colours get squeezed to 16-bit RGB565 (5-6-5 bits per channel), so tiny colour differences vanish: use clearly different colours.
- LEDs look harsher than a screen and the visor sits behind a dark smoked sheet: use high contrast, bright saturated colours, avoid dark greys/browns (they disappear).
- The talking faces swap one mouth sprite per sound level; keep the eyes/nose identical across talk/loud/yell frames and only change the mouth, or the face will flicker.
- GIFs: 64x32, keep the frame count/timings or tell me what you changed. The visor flash has room for a few more but long animations cost memory.
- File names matter: keep the existing names. New faces or boops need a firmware edit (I do that): tell me the name, what it should do, and which sprites it uses.

## How to send your edits back
Attach the edited PNG/GIF files (the same file names) in the chat with me. I convert them with convimg.py / convgif.py (to 16-bit RLE arrays), rebuild, back up the visor, and only flash when you say go.
Tip: you can edit with any pixel editor (Aseprite, Piskel, GIMP, Photoshop): set the canvas to 64x32, zoom in, no smoothing.
